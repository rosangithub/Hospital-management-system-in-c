#include <stdio.h>
#include <conio.h>
#include <string.h>
#include <ctype.h>
#include <stdlib.h>
#include "myHeaders.h"

int main()
{
    int choice;
    WelcomeScreen();
    LogIn();
    while(1)
    {
        system("cls");
        Title();
        printf("\n\n\t\t\t\t\t\t\t\t\t\t*******MAIN MENU********\n\n");
        printf("\t\t\t\t\t\t\t\t [1] Add new Patients \n");
        printf("\t\t\t\t\t\t\t\t [2] view patients details\n");
        printf("\t\t\t\t\t\t\t\t [3] Add new Doctor\n");
        printf("\t\t\t\t\t\t\t\t [4] view Doctor details\n");
        printf("\t\t\t\t\t\t\t\t [5] Search Patients By Id\n");
        printf("\t\t\t\t\t\t\t\t [6] Search Doctor By Id\n");
        printf("\t\t\t\t\t\t\t\t [7] Delete Patients records\n");
        printf("\t\t\t\t\t\t\t\t [8] Delete Doctors Records\n");
        printf("\t\t\t\t\t\t\t\t [9] Update Patient Records\n");
        printf("\t\t\t\t\t\t\t\t [10] Update Doctor Records\n");
        printf("\t\t\t\t\t\t\t\t [11] Exit\n");
        printf("\n\n\t\t\t\t\t\t\t\t Enter your choice!!!\n");
        scanf("%d",&choice);
        switch(choice)
        {
        case 1:
            system("cls");
            Title();
            Add_new_patients();
            break;
        case 2:
            system("cls");
            Title();
            Show_PatDetails();
            break;
        case 3:
            system("cls");
            Title();
            Add_new_doctor();
            break;
        case 4:
            system("cls");
            Title();
            Show_DocDetails();
            break;
        case 5:
            system("cls");
            Title();
            //Show_PatDetails();
            SearchPatientById();
            break;
        case 6:
            system("cls");
            Title();
            //Show_DocDetails();
            SearchDoctorById();
            break;
        case 7:
            system("cls");
            Title();
            Show_PatDetails();
            DeletePatients();
            break;
        case 8:
            system("cls");
            Title();
           // Show_DocDetails();
            DeleteDoctor();
            break;
        case 9:
            system("cls");
            Title();
            Update_patient();
            break;
        case 10:
            Title();
            Update_doctor();
            break;
        case 11:
            Title();
            Exit();
        default:
            system("cls");
            Title();
            printf(" your choice is wrong\n");
        }
    }
    return 0;
}
