#include<stdio.h>
#include<string.h>
#include<ctype.h>
#include "Structure.h"
int i;

// Function to update patient's first name
void Update_fName(struct patient *p)
{
A:
    printf("\n\t\t\t\t\t\t\t\tUpdate First Name: ");
    fflush(stdin);
    gets(p->first_name);
    for (int i = 0; i <= strlen(p->first_name); i++)
    {
        p->first_name[i] = toupper(p->first_name[i]);
    }
    if (strlen(p->first_name) < 2 || strlen(p->first_name) > 20)
    {
        printf("\t\t\t\t\t\t\t\tInvalid...:(  Max length of first name is 20 and min length is 2\n");
        goto A;
    }
    else
    {
        int valid = 1;
        for (int i = 0; i < strlen(p->first_name); i++)
        {
            if (!isalpha(p->first_name[i]))
            {
                valid = 0;
                break;
            }
        }
        if (valid)
        {
            printf("\n\t\t\t\t\t\t\t\tAll characters in the name are alphabets.\n");
        }
        else
        {
            printf("\n\t\t\t\t\t\t\t\tInvalid..!, First name contains non-alphabetic characters.\n");
            goto A;
        }
    }
}
void Update_lName(struct patient *p)
{
A:
    printf("\n\t\t\t\t\t\t\t\tUpdate  Last Name: ");
    fflush(stdin);
    gets(p->last_name);
    for (int i = 0; i <= strlen(p->last_name); i++)
    {
        p->last_name[i] = toupper(p->last_name[i]);
    }
    if (strlen(p->last_name) < 2 || strlen(p->last_name) > 20)
    {
        printf("\t\t\t\t\t\t\t\tInvalid...:(  Max length of first name is 20 and min length is 2\n");
        goto A;
    }
    else
    {
        int valid = 1;
        for (int i = 0; i < strlen(p->last_name); i++)
        {
            if (!isalpha(p->last_name[i]))
            {
                valid = 0;
                break;
            }
        }
        if (valid)
        {
            printf("\n\t\t\t\t\t\t\t\tAll characters in the name are alphabets.\n");
        }
        else
        {
            printf("\n\t\t\t\t\t\t\t\tInvalid..!, last name contains non-alphabetic characters.\n");
            goto A;
        }
    }
}
void Update_Address(struct patient *p)
{
C:
    printf("\n\t\t\t\t\t\t\t\tUpdate  Address: ");
    fflush(stdin);
    gets(p->address);
    for(i=0; i<=strlen(p->address); i++)
    {
        p->address[i]=toupper( p->address[i]);
    }
    if(strlen(p->address)<2||strlen(p->address)>20)
    {
        printf("\t\t\t\t\t\t\t\tInvalid...:(  max length of  Address is 30 and min length is 2\n");
        goto C;
    }
    else
    {
        int  valid=1;
        for (i = 0; i < strlen(p->address); i++)
        {
            if (!isalpha(p->address[i]))
            {
                valid = 0;
                break;
            }
        }
        if (valid)
        {
            printf("\n\t\t\t\t\t\t\t\tAll characters in the address are alphabets.\n");
        }
        else
        {
            printf("\n\t\t\t\t\t\t\t\tInvalid..!,Address contains non-alphabetic characters.\n");
            goto C;
        }
    }

}
void Update_Phone(struct patient*p)
{
    D:
    printf("\n\t\t\t\t\t\t\t\tUpdate Phone: ");
    fflush(stdin);
    gets(p->phone);
    if(strlen(p->phone)!=10)
    {
        printf("\n\t\t\t\t\t\t\t\t Invalid..:( phone number should be 10 digit");
        goto D;
    }
    else
    {
        int ok=0;
        for(i=0; i<strlen(p->phone); i++)
        {
            if(!isalpha(p->phone[i]))
            {
                ok=1;
            }
            else
            {
                ok=0;
                break;
            }
        }
        if(!ok)
        {
            printf("\n\t\t\t\t\t\t\t\t\tInvalid..:( Phone number should be only number");
            goto D;
        }
    }
}
 void Update_Age(struct patient*p)
 {
     E:
    printf("\n\t\t\t\t\t\t\t\tUpdate Age: ");
    scanf("%d",&p->age);
    if(p->age>120)
    {
        printf("\n\t\t\t\t\t\t\t\tEnter your correct age");
        goto E;
    }
 }
 void Update_Disease(struct patient *p)
 {
     printf("\n\t\t\t\t\t\t\t\tEnter updated Patient Disease: ");
    fflush(stdin);
    gets(p->disease);
    for(i=0; i<=strlen(p->disease); i++)
    {
        p->disease[i]=toupper( p->disease[i]);
    }

 }
 void Display(struct patient *p) {
    FILE *fptr;
    struct patient readPatient;  // Use a local variable to read from the file

    // Open the patient file for reading
    fptr = fopen("patient.text", "r");

    // Check if the file is successfully opened
    if (fptr == NULL) {
        printf("\n\t\t\t\t\t\t\t\tError opening file");
        return;
    }

    int patientId;  // Add a variable to store the patient ID
    printf("\n\t\t\t\t\t\t\t\tEnter Patient ID to display updated details: ");
    scanf("%d", &patientId);

    // Loop through each record in the patient file
    while (fread(&readPatient, sizeof(readPatient), 1, fptr) == 1) {
        // Check if the current record matches the specified ID
        if (patientId == readPatient.id) {
            // Display patient details
            printf("\n\t\t\t\t\t\t\t\tUpdated details ");
            printf("\n\t\t\t\t\t\t\t\tFirst Name: %s", readPatient.first_name);
            printf("\n\t\t\t\t\t\t\t\tLast Name : %s", readPatient.last_name);
            printf("\n\t\t\t\t\t\t\t\tAddress   : %s", readPatient.address);
            printf("\n\t\t\t\t\t\t\t\tPhone     : %s", readPatient.phone);
            printf("\n\t\t\t\t\t\t\t\tAge       : %d", readPatient.age);  // Assuming age is an integer
            printf("\n\t\t\t\t\t\t\t\tDisease   : %s", readPatient.disease);

            // Exit the loop since the information has been displayed
            break;
        }
    }

    // Close the patient file
    fclose(fptr);
}

