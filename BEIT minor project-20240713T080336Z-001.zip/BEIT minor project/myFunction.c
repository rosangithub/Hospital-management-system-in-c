#include<stdio.h>
#include<string.h>
#include<ctype.h>
#include "Structure.h"
#include<time.h>
int i;
/*Method to print the welcome screen*/
void WelcomeScreen()
{
    printf("\n\n\n");
    printf("\t\t\t\t\t\t\t\t*************************************************\n");
    printf("\t\t\t\t\t\t\t\t=================================================\n");
    printf("\t\t\t\t\t\t\t\t**                                             **\n");
    printf("\t\t\t\t\t\t\t\t**            WELCOME TO RSNA HOSPITAL         **\n");
    printf("\t\t\t\t\t\t\t\t**                                             **\n");
    printf("\t\t\t\t\t\t\t\t=================================================\n");
    printf("\t\t\t\t\t\t\t\t*************************************************\n");
    printf("\t\t\t\t\t\t\t\tPress any key for continue....\n");
    //system("cls");
}
/*Method to print the title  */
void Title()
{
    printf("\t\t\t\t\t\t\t\t==========================================================\n");
    printf("\t\t\t\t\t\t\t\t                     RSNA HOSPITAL                        \n");
    printf("\t\t\t\t\t\t\t\t==========================================================\n");
}
/*Method to add the new patients */
int Add_new_patients()
{
    FILE *fptr;
    fptr = fopen("patient.text", "a");
    struct patient p;
    printf("\n\t\t\t\t\t\t\t\t!!!!!!!!!!!!Add Patients Record!!!!!!!!!!!!\n\n");
    printf("\n\t\t\t\t\t\t\t\tEnter Patient id: ");
    scanf("%d", &p.id);
   char myDate[12];
    time_t t =time(NULL);
    struct tm tm=*localtime(&t);
    sprintf(myDate,"%02d/%02d/%d",tm.tm_mday,tm.tm_mon+1,tm.tm_year+1900);
    strcpy(p.Date,myDate);
A:
    printf("\n\t\t\t\t\t\t\t\tEnter Patient First  Name: ");
    fflush(stdin);
    gets(p.first_name);
    for(i=0; i<=strlen(p.first_name); i++)
    {
        p.first_name[i]=toupper( p.first_name[i]);
    }
    if(strlen(p.first_name)<2||strlen(p.first_name)>20)
    {
        printf("\t\t\t\t\t\t\t\tInvalid...:(  max length of  first name is 20 and min length is 2\n");
        goto A;
    }
    else
    {
        int  valid=1;
        for (i = 0; i < strlen(p.first_name); i++)
        {
            if (!isalpha(p.first_name[i]))
            {
                valid = 0;
                break;
            }
        }
        if (valid)
        {
            printf("\n\t\t\t\t\t\t\t\tAll characters in the name are alphabets.\n");
        }
        else
        {
            printf("\n\t\t\t\t\t\t\t\tInvalid..!,Last name contains non-alphabetic characters.\n");
            goto A;
        }
    }
B:
    printf("\n\t\t\t\t\t\t\t\tEnter Patient Last  Name: ");
    fflush(stdin);
    gets(p.last_name);
    for(i=0; i<=strlen(p.last_name); i++)
    {
        p.last_name[i]=toupper( p.last_name[i]);
    }
    if(strlen(p.last_name)<2||strlen(p.last_name)>20)
    {
        printf("\t\t\t\t\t\t\t\tInvalid...:(  max length of  last name is 30 and min length is 2\n");
        goto B;
    }
    else
    {
        int  valid=1;
        for (i = 0; i < strlen(p.last_name); i++)
        {
            if (!isalpha(p.last_name[i]))
            {
                valid = 0;
                break;
            }
        }
        if (valid)
        {
            printf("\n\t\t\t\t\t\t\t\tAll characters in the last name are alphabets.\n");
        }
        else
        {
            printf("\n\t\t\t\t\t\t\t\tInvalid..!,Last name contains non-alphabetic characters.\n");
            goto B;
        }
    }


C:
    printf("\n\t\t\t\t\t\t\t\tEnter Patient Address: ");
    fflush(stdin);
    gets(p.address);
    for(i=0; i<=strlen(p.address); i++)
    {
        p.address[i]=toupper( p.address[i]);
    }
    if(strlen(p.address)<2||strlen(p.address)>20)
    {
        printf("\t\t\t\t\t\t\t\tInvalid...:(  max length of  Address is 30 and min length is 2\n");
        goto C;
    }
    else
    {
        int  valid=1;
        for (i = 0; i < strlen(p.address); i++)
        {
            if (!isalpha(p.address[i]))
            {
                valid = 0;
                break;
            }
        }
        if (valid)
        {
            printf("\n\t\t\t\t\t\t\t\tAll characters in the address are alphabets.\n");
        }
        else
        {
            printf("\n\t\t\t\t\t\t\t\tInvalid..!,Address contains non-alphabetic characters.\n");
            goto C;
        }
    }

D:
    printf("\n\t\t\t\t\t\t\t\tEnter Patient Phone: ");
    fflush(stdin);
    gets(p.phone);
    if(strlen(p.phone)!=10)
    {
        printf("\n\t\t\t\t\t\t\t\t Invalid..:( phone number should be 10 digit");
        goto D;
    }
    else
    {
        int ok=0;
        for(i=0; i<strlen(p.phone); i++)
        {
            if(!isalpha(p.phone[i]))
            {
                ok=1;
            }
            else
            {
                ok=0;
                break;
            }
        }
        if(!ok)
        {
            printf("\n\t\t\t\t\t\t\t\t\tInvalid..:( Phone number should be only number");
            goto D;
        }
    }
E:
    printf("\n\t\t\t\t\t\t\t\tEnter Patient Age: ");
    scanf("%d",&p.age);
    if(p.age>120)
    {
        printf("\n\t\t\t\t\t\t\t\tEnter your correct age");
        goto E;
    }

F:
    printf("\n\t\t\t\t\t\t\t\tEnter Gender (M/F/O): ");
    fflush(stdin);
    scanf("%c",&p.gender);
    int ok=0;
    p.gender=toupper(p.gender);
    if(p.gender=='M'||p.gender=='F'||p.gender=='O')
    {
        ok=1;
    }
    if(!ok)
    {
        printf("\n\t\t\t\t\t\t\t\tInvalid..:( Gender contains invalid character");
        goto F;
    }

    printf("\n\t\t\t\t\t\t\t\tEnter Patient Disease: ");
    fflush(stdin);
    gets(p.disease);
    for(i=0; i<=strlen(p.disease); i++)
    {
        p.disease[i]=toupper( p.disease[i]);
    }

    printf("\n\t\t\t\t\t\t\t\tPreferred doctor");
G:
    printf("\n\t\t\t\t\t\t\t\tEnter doctor   Name: ");
    fflush(stdin);
    gets(p.doctor);
    for(i=0; i<=strlen(p.doctor); i++)
    {
        p.doctor[i]=toupper( p.doctor[i]);
    }
    if(strlen(p.doctor)<2||strlen(p.doctor)>20)
    {
        printf("\t\t\t\t\t\t\t\tInvalid...:(  max length of  first name is 30 and min length is 2\n");
        goto G;
    }
    else
    {
        int  valid=1;
        for (i = 0; i < strlen(p.doctor); i++)
        {
            if (!isalpha(p.first_name[i]))
            {
                valid = 0;
                break;
            }
        }
        if (valid)
        {
            printf("\n\t\t\t\t\t\t\t\tAll characters in the name are alphabets.\n");
        }
        else
        {
            printf("\n\t\t\t\t\t\t\t\tInvalid..!,First name contains non-alphabetic characters.\n");
            goto G;
        }
    }

    printf("\n\t\t\t\t\t\t\t\tPatient Added Successfully");
    getch();
    fwrite(&p, sizeof(p), 1, fptr);
    fclose(fptr);
    return;
}
void Show_PatDetails()
{
    printf("\n\t\t\t\t\t\t\t<== Patient List ==>\n\n");
    printf("%-10s %-15s %-15s %-15s %-15s %-15s %-5s %-15s %-15s %s\n", "Id", "First Name","Last Name", " Address", "Phone",  "Age", "Gender", "Disease","Doctor","Date");
    printf("--------------------------------------------------------------------------------------------------------------------------------------------------------------\n");
    FILE *fptr;
    fptr = fopen("patient.text", "rb");
    if(fptr==NULL)
    {
        printf("\n\t\t\t\t\t\t\t\t\tError!! opening file");
        getch();
        return;
    }
    else
    {
        struct patient p;
        while(fread(&p, sizeof(p), 1, fptr) == 1)
        {
            printf("%-10d %-15s %-15s %-15s %-15s %-15d %-15c %-15s %-15s %s\n", p.id, p.first_name, p.last_name, p.address, p.phone, p.age, p.gender, p.disease, p.doctor, p.Date);
        }
        /*
           while (fscanf(fptr, "%d %s %s %s %s %d %c %s %s %s", &p.id, p.first_name, p.last_name, p.address, p.phone, &p.age, &p.gender, p.disease, p.doctor, p.Date) == 10) {
            printf("%-10d %-15s %-15s %-15s %-15s %-15d %-5c %-15s %-15s %s\n", p.id, p.first_name, p.last_name, p.address, p.phone, p.age, p.gender, p.disease, p.doctor, p.Date);
           }*/
        fclose(fptr);
        getch();
    }
}
int Add_new_doctor()
{
    FILE *fdtr;
    fdtr = fopen("doctor.text", "a");
    struct doctor d;
    printf("\n\t\t\t\t\t\t\t\t!!!!!!!!!!!!Add doctors Record!!!!!!!!!!!!\n\n");

    printf("\n\t\t\t\t\t\t\t\tEnter doctor id: ");
    scanf("%d", &d.id);
    char myDate[12];
    time_t t =time(NULL);
    struct tm tm=*localtime(&t);
    sprintf(myDate,"%02d/%02d/%d",tm.tm_mday,tm.tm_mon+1,tm.tm_year+1900);
    strcpy(d.Date,myDate);
A:
    printf("\n\t\t\t\t\t\t\t\tEnter doctor First  Name: ");
    fflush(stdin);
    gets(d.first_name);
    for(i=0; i<=strlen(d.first_name); i++)
    {
        d.first_name[i]=toupper( d.first_name[i]);
    }
    if(strlen(d.first_name)<2||strlen(d.first_name)>20)
    {
        printf("\t\t\t\t\t\t\t\tInvalid...:(  max length of  first name is 30 and min length is 2\n");
        goto A;
    }
    else
    {
        int  valid=1;
        for (i = 0; i < strlen(d.first_name); i++)
        {
            if (!isalpha(d.first_name[i]))
            {
                valid = 0;
                break;
            }
        }
        if (valid)
        {
            printf("\n\t\t\t\t\t\t\t\tAll characters in the name are alphabets.\n");
        }
        else
        {
            printf("\n\t\t\t\t\t\t\t\tInvalid..!,First name contains non-alphabetic characters.\n");
            goto A;
        }
    }
B:
    printf("\n\t\t\t\t\t\t\t\tEnter doctor Last  Name: ");
    fflush(stdin);
    gets(d.last_name);
    for(i=0; i<=strlen(d.last_name); i++)
    {
        d.last_name[i]=toupper( d.last_name[i]);
    }
    if(strlen(d.last_name)<2||strlen(d.last_name)>20)
    {
        printf("\t\t\t\t\t\t\t\tInvalid...:(  max length of  last name is 30 and min length is 2\n");
        goto B;
    }
    else
    {
        int  valid=1;
        for (i = 0; i < strlen(d.last_name); i++)
        {
            if (!isalpha(d.last_name[i]))
            {
                valid = 0;
                break;
            }
        }
        if (valid)
        {
            printf("\n\t\t\t\t\t\t\t\tAll characters in the last name are alphabets.\n");
        }
        else
        {
            printf("\n\t\t\t\t\t\t\t\tInvalid..!,First name contains non-alphabetic characters.\n");
            goto B;
        }
    }
C:
    printf("\n\t\t\t\t\t\t\t\tEnter doctor Address: ");
    fflush(stdin);
    gets(d.address);
    for(i=0; i<=strlen(d.address); i++)
    {
        d.address[i]=toupper( d.address[i]);
    }
    if(strlen(d.address)<2||strlen(d.address)>20)
    {
        printf("\t\t\t\t\t\t\t\tInvalid...:(  max length of  Address is 30 and min length is 2\n");
        goto C;
    }
    else
    {
        int  valid=1;
        for (i = 0; i < strlen(d.address); i++)
        {
            if (!isalpha(d.address[i]))
            {
                valid = 0;
                break;
            }
        }
        if (valid)
        {
            printf("\n\t\t\t\t\t\t\t\tAll characters in the address are alphabets.\n");
        }
        else
        {
            printf("\n\t\t\t\t\t\t\t\tInvalid..!,Address contains non-alphabetic characters.\n");
            goto C;
        }
    }

D:
    printf("\n\t\t\t\t\t\t\t\tEnter doctor phone: ");
    fflush(stdin);
    gets(d.phone);
    if(strlen(d.phone)!=10)
    {
        printf("\n\t\t\t\t\t\t\t\tInvalid..:( phone number should be 10 digit");
        goto D;
    }
    else
    {
        int ok=0;
        for(i=0; i<strlen(d.phone); i++)
        {
            if(!isalpha(d.phone[i]))
            {
                ok=1;
            }
            else
            {
                ok=0;
                break;
            }
        }
        if(!ok)
        {
            printf("\n\t\t\t\t\t\t\t\t\tInvalid..:( phone number should be only number");
            goto D;
        }
    }
    printf("\n\t\t\t\t\t\t\t\tEnter doctor specialize: ");
    fflush(stdin);
    gets(d.specialize);
    for(i=0; i<=strlen(d.specialize); i++)
    {
        d.specialize[i]=toupper( d.specialize[i]);
    }
    printf("\n\t\t\t\t\t\t\t\tDoctor Added Successfully");
    getch();
    fwrite(&d, sizeof(d), 1, fdtr);
    fclose(fdtr);
    return ;
}


void Show_DocDetails()
{
    printf("\n\t\t\t\t\t\t<== doctor List ==>\n\n");
    printf("%-10s %-20s %-20s %-20s %-20s %-20s %s\n", "Id", "First Name","Last Name", "Doctors Address", "Phone", "Specialize","Join Date");
    printf("-----------------------------------------------------------------------------------------------------------------------\n");
    FILE *fdtr;
    fdtr = fopen("doctor.text", "r");
    if(fdtr==NULL)
    {
        printf("\n\t\t\t\t\t\t\t\t\tError!! opening file");
        getch();
        return;
    }
    else
    {
        struct doctor d;
        while(fread(&d, sizeof(d), 1, fdtr) == 1)
        {
            printf("%-10d %-20s %-20s %-20s %-20s %-20s %s\n", d.id, d.first_name, d.last_name, d.address,d.phone, d.specialize,d.Date );
        }
        fclose(fdtr);
        getch();

    }
}


int SearchPatientById()
{
    int found = 0;
    int patientId;
    FILE *fptr;
    struct patient p;

    fptr = fopen("patient.text", "r");

    if (fptr == NULL)
    {
        printf("Error opening the file\n");
        return;
    }
    else
    {
        printf("\n\t\t\t\t\t\t\t\tEnter patient Id to search: \n");
        fflush(stdin);
        scanf("%d", &patientId);

        // Store the found patient's details
        struct patient foundPatient;

       while (fread(&p, sizeof(struct patient), 1, fptr)==1)
        {

            if (p.id == patientId)
            {
                found = 1;
                foundPatient = p;  // Store the details of the found patient
                break;  // Exit the loop once a matching patient is found
            }
        }

        if (found == 0)
        {
            printf("Sorry..:( Patient not Found, please enter correct patient Id\n");
        }
        else
        {
            // Display the details of the found patient
            printf("\n\t\t\t\t\t\t\t\tPatient Found! Details:\n");
            printf("\n\t\t\t\t\t\t\t\tID        : %d\n", foundPatient.id);
            printf("\n\t\t\t\t\t\t\t\tFirst Name: %s\n", foundPatient.first_name);
            printf("\n\t\t\t\t\t\t\t\tLast Name : %s\n", foundPatient.last_name);
            printf("\n\t\t\t\t\t\t\t\tAddress   : %s\n", foundPatient.address);
            printf("\n\t\t\t\t\t\t\t\tPhone     : %s\n", foundPatient.phone);
            printf("\n\t\t\t\t\t\t\t\tAge       : %d\n", foundPatient.age);
            printf("\n\t\t\t\t\t\t\t\tGender    : %c\n", foundPatient.gender);
            printf("\n\t\t\t\t\t\t\t\tDisease   : %s\n", foundPatient.disease);
        }
        getch();

        fclose(fptr);
    }
    return;
}
int SearchDoctorById()
{
    int found=0;
    int DoctorId;
    FILE *fdtr;
    struct doctor d;
    fdtr= fopen("doctor.text","r");
    if(fdtr==NULL)
    {
        printf("Error...!opening the file");
        getch();
        return;
    }
    else
    {
        printf("\n\t\t\t\t\t\t\t\tEnter doctor Id to search: \n");
        fflush(stdin);
        scanf("%d",&DoctorId);
        struct doctor foundDoctor;
        while(fread(&d,sizeof(d),1,fdtr)==1)
        {
            if(d.id==DoctorId)
            {
                found=1;
                foundDoctor=d;
                break;
            }
        }
        if(found==0)
        {
            printf("\n\t\t\t\t\t\t\t\t Sorry..:( doctor not Found,please Enter correct doctor Id\n");
            getch();
        }
        else
        {
            printf("\n\t\t\t\t\t\t\t\t doctor Found! Details:\n");
            printf("\n\t\t\t\t\t\t\t\tID          : %d\n", foundDoctor.id);
            printf("\n\t\t\t\t\t\t\t\tFirst Name  : %s\n", foundDoctor.first_name);
            printf("\n\t\t\t\t\t\t\t\tLast Name   : %s\n", foundDoctor.last_name);
            printf("\n\t\t\t\t\t\t\t\tAddress     : %s\n", foundDoctor.address);
            printf("\n\t\t\t\t\t\t\t\tPhone       : %s\n",  foundDoctor.phone);
            printf("\n\t\t\t\t\t\t\t\tSpecialize  : %s\n", foundDoctor.specialize);
            getch();

        }

    }
    return;
}
void Exit()
{
    printf("\n\n\n\n\n\t\t\t\t\t\t\t\t(:-:-:-:THANK YOU FOR VISISTING:-:-:-:");
    getch();
    exit(0);
}

int LogIn()
{
    int count;
    char Username[15];
    char Password[15];
    char Original_Username[15]="Rsna";
    char Original_Password[15]="123";
    do
    {
        printf("\n\t\t\t\t\t\t\t\tEnter User Name :");
        fflush(stdin);
        gets(Username);
        printf("\n\t\t\t\t\t\t\t\tEnter Password :");
        fflush(stdin);
        gets(Password);

        if(strcmp(Username,Original_Username)==0&&strcmp(Password,Original_Password)==0)
        {
            printf("\n\t\t\t\t\t\t\t\tLogin Successful :)");
            getch();
            break;
        }
        else
        {
            printf("\n\t\t\t\t\t\t\t\tIncorrect.. User name or Password\n");
            count++;
        }
    }
    while(count<3);
    if(count>=3)
    {
        printf("\n\t\t\t\t\t\t\t\tSorry...:you cannot enter more than 3 times(  Try again later");
        Exit();
        exit(0);
    }
    return 0;

}
void DeletePatients()
{
    int PatientId, found = 0;
    FILE *fptr, *tmp;
    struct patient p;

    // Open the patient file for reading
    fptr = fopen("patient.text", "r");

    // Open a temporary file for writing
    tmp = fopen("temp.text", "w");

    // Prompt user for the ID of the patient to be deleted
    printf("\n\t\t\t\t\t\t\t\tEnter Patient's ID you want to delete: ");
    scanf("%d", &PatientId);

    // Check if files are successfully opened
    if (fptr == NULL || tmp == NULL)
    {
        printf("\n\t\t\t\t\t\t\t\tError opening files");
    }
    else
    {
        // Loop through each record in the patient file
        while (fread(&p, sizeof(p), 1, fptr) == 1)
        {
            // Check if the current record matches the specified ID
            if (PatientId == p.id)
            {
                found = 1;  // Set found flag to indicate the patient is found
            }
            else
            {
                // If the current record does not match, write it to the temporary file
                fwrite(&p, sizeof(p), 1, tmp);
            }
        }

        // Display a message based on whether the patient was found and deleted
        if (found == 1)
        {
            printf("\n\t\t\t\t\t\t\t\tPatient deleted successfully");
        }
        else
        {
            printf("\n\t\t\t\t\t\t\t\tSorry, patient not found");
        }

        // Close both the patient file and the temporary file
        fclose(fptr);
        fclose(tmp);

        // Remove the original patient file
        remove("patient.text");

        // Rename the temporary file to replace the original patient file
        rename("temp.text", "patient.text");

        getch();
    }
}
void DeleteDoctor()
{
    int DoctorId, found = 0;
    FILE *fdtr,*tmp;
    struct doctor d;

    // Open the doctor file for reading
    fdtr = fopen("doctor.text", "r");

    // Open a temporary file for writing
    tmp = fopen("tempo.text", "w");

    // Prompt user for the ID of the doctor to be deleted
    printf("\n\t\t\t\t\t\t\t\tEnter Doctor's ID you want to delete: ");
    scanf("%d", &DoctorId);

    // Check if files are successfully opened
    if (fdtr == NULL || tmp == NULL)
    {
        printf("\n\t\t\t\t\t\t\t\tError opening files");
    }
    else
    {
        // Loop through each record in the doctor file
        while (fread(&d, sizeof(d), 1, fdtr) == 1)
        {
            // Check if the current record matches the specified ID
            if (DoctorId == d.id)
            {
                found = 1;  // Set found flag to indicate the doctor is found
            }
            else
            {
                // If the current record does not match, write it to the temporary file
                fwrite(&d, sizeof(d), 1, tmp);
            }
        }

        // Display a message based on whether the doctor was found and deleted
        if (found == 1)
        {
            printf("\n\t\t\t\t\t\t\t\tDoctor deleted successfully");
        }
        else
        {
            printf("\n\t\t\t\t\t\t\t\tSorry, Doctor not found");
        }

        // Close both the doctor file and the temporary file
        fclose(fdtr);
        fclose(tmp);

        // Remove the original doctor file
        remove("doctor.text");

        // Rename the temporary file to replace the original doctor file
        rename("tempo.text", "doctor.text");

        getch();
    }
}
// Function to update patient information


// Function declarations
//void Update_fName(struct patient *p);

// Function to update patient information
void Update_patient()
{
    int patientId, found = 0, choose;
    FILE *fptr;
    struct patient p;
    struct patient readPatient;

    // Open the patient file for updating
    fptr = fopen("patient.text", "r+");

    // Check if the file is successfully opened
    if (fptr == NULL)
    {
        printf("\n\t\t\t\t\t\t\t\tError opening file");
        return;
    }

    // Prompt user for the ID of the patient to be updated
    printf("\n\t\t\t\t\t\t\t\tEnter Patient's ID you want to update: ");
    scanf("%d", &patientId);

    // Loop through each record in the patient file
    while (fread(&p, sizeof(p), 1, fptr) == 1)
    {
        // Check if the current record matches the specified ID
        if (patientId == p.id)
        {
            found = 1; // Set found flag to indicate the patient is found

            // Prompt user for updated information
            printf("\n\t\t\t\t\t\t\t\tEnter updated information for patient with ID %d:\n", patientId);

            // Display options for updating patient details
            printf("\n\t\t\t\t\t\t\t\t [1]. First Name");
            printf("\n\t\t\t\t\t\t\t\t [2]. Last Name");
            printf("\n\t\t\t\t\t\t\t\t [3]. Address");
            printf("\n\t\t\t\t\t\t\t\t [4]. Phone Number");
            printf("\n\t\t\t\t\t\t\t\t [5]. Age");
            printf("\n\t\t\t\t\t\t\t\t [6]. Disease");
            // Add other options for updating fields...
            printf("\n\t\t\t\t\t\t\t\tEnter your choice: ");
            scanf("%d", &choose);

            switch (choose)
            {
            case 1:
                system("cls");
                Title();
                Update_fName(&p);
                break;
            // Add cases for other fields as needed...
            case 2:
                system("cls");
                Title();
                Update_lName(&p);
                break;
            case 3:
                system("cls");
                Title();
                Update_Address(&p);
                break;
            case 4:
                system("cls");
                Title();
                Update_Phone(&p);
                break;
            case 5:
                system("cls");
                Title();
                Update_Age(&p);
                break;
            case 6:
                system("cls");
                Title();
                Update_Disease(&p);
                break;
            default:
                system("cls");
                Title();
                printf("\n\t\t\t\t\t\t\t\tInvalid..:( choice");
            }

            // Move the file pointer back to the beginning of the record for updating
            fseek(fptr, -sizeof(p), SEEK_CUR);

            // Write the updated record back to the file
            fwrite(&p, sizeof(p), 1, fptr);

            // Exit the loop since the update is done
            break;
        }
    }

    // Display a message based on whether the patient was found and updated
    if (found == 1)
    {
        printf("\n\t\t\t\t\t\t\t\tPatient updated successfully");
        Display(&readPatient);
    }
    else
    {
        printf("\n\t\t\t\t\t\t\t\tSorry, patient not found");
    }

    // Close the patient file
    fclose(fptr);
    getch(); // Assuming getch() is defined elsewhere in your code
}

void Update_doctor()
{
    int doctorID, found = 0, choose;
    FILE *fdtr;
    struct doctor d;

    // Open the doctor file for updating
    fdtr = fopen("doctor.text", "r+");

    // Check if the file is successfully opened
    if (fdtr == NULL)
    {
        printf("\n\t\t\t\t\t\t\t\tError opening file");
        return;
    }

    // Prompt user for the ID of the doctor to be updated
    printf("\n\t\t\t\t\t\t\t\tEnter doctor's ID you want to update: ");
    scanf("%d", &doctorID);

    // Loop through each record in the doctor file
    while (fread(&d, sizeof(d), 1, fdtr) == 1)
    {
        // Check if the current record matches the specified ID
        if (doctorID == d.id)
        {
            found = 1; // Set found flag to indicate the doctor is found

            // Prompt user for updated information
            printf("\n\t\t\t\t\t\t\t\tEnter updated information for doctor with ID %d:\n", doctorID);

            // Display options for updating doctor details
            printf("\n\t\t\t\t\t\t\t\t [1]. First Name");
            printf("\n\t\t\t\t\t\t\t\t [2]. Last Name");
            printf("\n\t\t\t\t\t\t\t\t [3]. Address");
            printf("\n\t\t\t\t\t\t\t\t [4]. Phone Number");
            printf("\n\t\t\t\t\t\t\t\t [5]. specialize");
            // Add other options for updating fields...
            printf("\n\n\t\t\t\t\t\t\t\tEnter your choice: ");
            scanf("%d", &choose);

            switch (choose)
            {
            case 1:
                system("cls");
                Title();
                Update_fName(&d);
                break;
            // Add cases for other fields as needed...
            case 2:
                system("cls");
                Title();
                Update_lName(&d);
                break;
            case 3:
                system("cls");
                Title();
                Update_Address(&d);
                break;
            case 4:
                system("cls");
                Title();
                Update_Phone(&d);
                break;
            case 5:
                system("cls");
                Title();
                Update_Age(&d);
                break;
            case 6:
                system("cls");
                Title();
                Update_Disease(&d);
                break;
            default:
                system("cls");
                Title();
                printf("\n\t\t\t\t\t\t\t\tInvalid..:( choice");
            }

            // Move the file pointer back to the beginning of the record for updating
            fseek(fdtr, -sizeof(d), SEEK_CUR);

            // Write the updated record back to the file
            fwrite(&d, sizeof(d), 1, fdtr);

            // Exit the loop since the update is done
            break;
        }
    }

    // Display a message based on whether the doctor was found and updated
    if (found == 1)
    {
        printf("\n\t\t\t\t\t\t\t\tDoctor updated successfully");
    }
    else
    {
        printf("\n\t\t\t\t\t\t\t\tSorry, doctor not found");
    }

    // Close the doctor file
    fclose(fdtr);
    getch(); // Assuming getch() is defined elsewhere in your code
}





