
struct patient
{
    int id;
    char first_name[50];
    char last_name[50];
    char address[50];
    char phone[11];
    int age;
    char gender;
    char disease[50];
    char doctor[50];
    char Date[12];

};
struct doctor{
    int id;
    char first_name[50];
    char last_name[50];
    char address[50];
    char phone[11];
    char specialize[50];
    char Date[12];



};

